#!/bin/sh
# Кладёт книжные шрифты в android/assets/fonts.
#
# В репозитории их нет намеренно: пять мегабайт бинарников в истории git никому
# не нужны, а взять их всегда можно из официального зеркала Google Fonts.
# Скрипт идемпотентный — уже скачанные файлы пропускает.
#
# Запускать из корня репозитория:  ./fetch-fonts.sh

set -e

BASE="https://raw.githubusercontent.com/google/fonts/main"
DEST="android/assets/fonts"

if [ ! -f ./fetch-fonts.sh ]; then
	echo "Запускать нужно из корня репозитория." >&2
	exit 1
fi

mkdir -p "$DEST"

fetch() {
	src="$1"
	name="$2"
	if [ -s "$DEST/$name" ]; then
		echo "уже на месте: $name"
		return 0
	fi
	echo "качаю: $name"
	curl -fsSL --retry 3 -o "$DEST/$name" "$BASE/$src"
}

# Charis SIL — основная книжная гарнитура: сделана для длинного чтения,
# полная кириллица, четыре начертания статикой (движку так надёжнее).
fetch "ofl/charissil/CharisSIL-Regular.ttf"    "CharisSIL-Regular.ttf"
fetch "ofl/charissil/CharisSIL-Bold.ttf"       "CharisSIL-Bold.ttf"
fetch "ofl/charissil/CharisSIL-Italic.ttf"     "CharisSIL-Italic.ttf"
fetch "ofl/charissil/CharisSIL-BoldItalic.ttf" "CharisSIL-BoldItalic.ttf"

# Literata — второй книжный вариант, заметно другой ритм строки.
fetch "ofl/literata/Literata%5Bopsz,wght%5D.ttf" "Literata.ttf"

# Onest — интерфейс приложения и строка состояния страницы.
fetch "ofl/onest/Onest%5Bwght%5D.ttf" "Onest.ttf"

# Cormorant Garamond — заголовки библиотеки, дисплейная гарнитура Riviera.
fetch "ofl/cormorantgaramond/CormorantGaramond%5Bwght%5D.ttf" "CormorantGaramond.ttf"

echo
echo "Готово. Шрифты в $DEST:"
ls -1 "$DEST"
